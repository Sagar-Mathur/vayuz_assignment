import React from 'react'

export const Header = () => {
    return (
        <div className='navBar'>Securing Your Flutter App: Best Practices and Techniques  </div>
    )
}
